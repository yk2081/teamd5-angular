console.log(‘PostgreSQL GET Function’);
var pg = require(“pg”);
exports.handler = function(event, context) {
var conn = “postgres://as:teamd5teamd5@teamd5.c2pdixcrwchd.us-east-1.rds.amazonaws.com/teamd5";
var client = new pg.Client(conn);
client.connect();
//var id = event.id;
console.log(‘Connected to PostgreSQL database’);
var query = client.query(“SELECT * from Jobs limit 10;”);
query.on(“row”, function (row, result) {
 result.addRow(row);
});
query.on(“end”, function (result) {
 var jsonString = JSON.stringify(result.rows);
 var jsonObj = JSON.parse(jsonString);
 console.log(jsonString);
 client.end();
 context.succeed(jsonObj);
});
};
